## Use Fab Design Rules in Eagle

This will help you make sure that traces are not too close together!

In this folder, find ``` fab.dru ```

In Eagle, in the Board Window, find ``` edit >> design rules ``` 

On the first tab, use 'load' and load this .dru file.

Now you can use the 'DRC' command to check!


# Fab Electronics Library for Eagle

This library (should) cover all the electronics components found in the official [fab inventory](http://fab.cba.mit.edu/about/fab/inv.html). Using this library should also make it easier to share Eagle project files. 

## Installation

TODO...

## Contributing

Please refer to the [CONTRIBUTING](CONTRIBUTING.md) document. Run `test.py` locally before `git push`.

## License

Please refer to the [LICENSE](LICENSE) document located in this repository. 

