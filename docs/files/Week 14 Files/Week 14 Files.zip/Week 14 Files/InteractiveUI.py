import serial
import time
import tkinter as tk
from tkinter import font

# Serial port configuration
ser = serial.Serial('COM3', 115200, timeout=1)
time.sleep(2)

# Tkinter GUI setup
root = tk.Tk()
root.title("Temperature and Humidity Monitor")

# Configure font styles
label_font = font.Font(family="Helvetica", size=16, weight="bold")
value_font = font.Font(family="Verdana", size=20)

# Create frames
hello_frame = tk.Frame(root)
temp_frame = tk.Frame(root)
humidity_frame = tk.Frame(root)

# Page 1: Hello Ryan
hello_frame_label = tk.Label(hello_frame, text="Hello Ryan", font=label_font, padx=10, pady=10)
hello_frame_label.pack()

# Page 2: Temperature
temperature_label = tk.Label(temp_frame, text="Temperature: ", font=label_font, padx=10, pady=10)
temperature_label.pack()

temperature_value = tk.Label(temp_frame, text="", font=value_font, padx=10, pady=5)
temperature_value.pack()

# Page 3: Humidity
humidity_label = tk.Label(humidity_frame, text="Humidity: ", font=label_font, padx=10, pady=10)
humidity_label.pack()

humidity_value = tk.Label(humidity_frame, text="", font=value_font, padx=10, pady=5)
humidity_value.pack()

# Navigation functions
def show_hello_page():
    hello_frame.pack()
    temp_frame.pack_forget()
    humidity_frame.pack_forget()

def show_temp_page():
    hello_frame.pack_forget()
    temp_frame.pack()
    humidity_frame.pack_forget()

def show_humidity_page():
    hello_frame.pack_forget()
    temp_frame.pack_forget()
    humidity_frame.pack()

# Buttons for navigation
temp_button = tk.Button(root, text="Temperature", font=label_font, command=show_temp_page)
temp_button.pack()

humidity_button = tk.Button(root, text="Humidity", font=label_font, command=show_humidity_page)
humidity_button.pack()

# Update values function
def update_values():
    line = ser.readline().decode("utf-8").strip()
    if line.startswith("temperature:") and "humidity:" in line:
        temperature = line.split("temperature:")[1].split("C")[0].strip()
        humidity = line.split("humidity:")[1].split("%RH")[0].strip()
        temperature_value.config(text=temperature + "C")
        humidity_value.config(text=humidity + "%")
    root.after(1000, update_values)

# Start updating values
update_values()

# Initial page: Hello Ryan
show_hello_page()

# Center the window on the screen
window_width = 300
window_height = 200
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = int((screen_width / 2) - (window_width / 2))
y = int((screen_height / 2) - (window_height / 2))
root.geometry(f"{window_width}x{window_height}+{x}+{y}")

# Run the Tkinter event loop
root.mainloop()
